private static Cache cache = CacheManager.getInstance().getCache(CACHE_NAME);

public static HashMap<String, XXX> getxxCodes(int version) {
        HashMap<String, XXX> xxCodes = new HashMap<String, XXX>();
        try{
            Object[] cacheResult = cache.get(Constants.I_XX_CODES_FOR_XXX);
            if (Boolean.FALSE.equals(cacheResult[1])) {
        cache.put(Constants.I_XX_CODES_FOR_XXX, id.loadXXHashMap(version));
                cacheResult = cache.get(Constants.I_XX_CODES_FOR_XXX);
            }
            if(cacheResult[0]!=null){
                xxCodes = (HashMap<String, XXX>)cacheResult[0];
            }
        }catch(Exception e){
            logger.error("Exception occured while loading Data from I10_DRG_XX",e);
        }
        return xxCodes;
    }
