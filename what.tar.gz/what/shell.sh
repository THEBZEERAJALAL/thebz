#!/bin/sh
cd /mnt/seagatehdd/Axis/Data_Processing/program
java -Dlog4j.configuration=file:log4j.properties -jar DataProcessing-0.0.1-SNAPSHOT-jar-with-dependencies.jar /mnt/seagatehdd/Axis/Data_Processing/resources/application.properties
a=$(ps -ef | grep DataProcessing| cut -d' ' -f3)

&& while true \
&& do sleep 1s \
&& top -n 1 -b | grep $a >> /home/rzt-dl/axis-app-memory.log \
&& done \
&& sudo iotop --batch -P -p $a >> /home/rzt-dl/axis-app-io.log \







