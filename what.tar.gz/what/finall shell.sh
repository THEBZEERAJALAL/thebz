#!/bin/sh
memory_log_path="$1"
io_log_path="$2"
disk_space="$3"
cd /mnt/seagatehdd/Axis/Data_Processing/program
rm -rf ../Processed_Data

#run Axis program
java -Dlog4j.configuration=file:log4j.properties -jar DataProcessing-0.0.1-SNAPSHOT-jar-with-dependencies.jar /mnt/seagatehdd/Axis/Data_Processing/resources/application.properties >> /dev/null &
#count the value
count=$(ps -ef | grep DataProcessing | wc -l)
echo "  PID USER      PR  NI    VIRT    RES    SHR S  %CPU %MEM     TIME+ COMMAND">$memory_log_path
#if count is two then the process is still running
while [ $count -eq 2 ]
do
#pid value 
pid=$(ps -ef | grep DataProcessing | cut -d' ' -f6 | head -1)
while true &
 do
 sleep 1
 top -n 1 -b | grep $pid >> $memory_log_path
 done
 sudo iotop -q -d 1 --batch -P -p $pid >> $io_log_path
count=$(ps -ef | grep DataProcessing | wc -l)
done
#disk space
du -h /mnt/seagatehdd/Axis/Data_Processing/Processed_Data/ > $disk_space


