/**
 * Created by kevin on 18/1/17.
 */

import java.io.IOException;
import java.util.*;


public class ResourceBundleDemo {
    public static void main(String[] args) throws IOException {
        final Runtime rt = Runtime.getRuntime();
        if(System.getProperty("os.name").equals("Linux"))
        {
            System.out.println("Clearing cache");
            rt.exec("sudo su"); 
            rt.exec("echo 3 > /proc/sys/vm/drop_caches");

            System.out.println("Cache Cleared in the linux system");
        }

        else if(System.getProperty("os.name").equals("Windows"))
        {
            System.out.println("Clearing cache");
            rt.exec("ipconfig/flushdns");
            System.out.println("Cache cleared in the Windows System");
        }
        else if(System.getProperty("os.name").equals("MacOS")||System.getProperty("os.name").equals("Yosemite"))
        {
            System.out.println("Clearing cache");
            rt.exec("purge");
            System.out.println("Cache cleared in the Mac");
        }
    }
}
