x= [[1,0,2],
    [2,3,6],
    [36, 56, 48]]
y=[[1,3,6],
  [2,6,9],
  [5,6,9]]

result=[[0,0,0],[0,0,0],[0,0,0]]
for i in range(len(x)):
    for  j in range(len(x[0])):
        result[i][j]=x[i][j]+y[i][j]

for r in result:
    print(r)

