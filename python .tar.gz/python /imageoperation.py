from scipy.misc import imread, imsave, imresize


img = imread('/home/thebzeera/Desktop/images.jpg')
print(img.dtype, img.shape)

img_tinted = img * [1, 0.95, 0.9]

# Resize the tinted image to be 300 by 300 pixels.
img_tinted = imresize(img_tinted, (300, 300))

imsave('/home/thebzeera/Desktop/images.jpg', img_tinted)