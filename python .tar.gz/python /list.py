#LIST
a=[1,2,3,6]
print(a[-1])
a.append('thebz')#append a new string
print(a)
a.pop()#removing the last element and returning
print(a)
#SLICING
nums =range(5)
print(nums)
print(nums[2:4])
print(nums[2:])
print(nums[:2])
print(nums[:])


#LOOP
animals=['dog','cat','elephant']
print(animals)
for animal in animals:
    print(animal)
for idx, animal in enumerate(animals):
    print (('#%d: %s') % (idx+1, animal))


#LIST COMPREHENSION
#program for square the numbers
number=[0,1,2,3,4]
squares =[]
for x in number:
    squares.append(x**2)
print(squares)



#same program by using comprehence
num=[2,3,6,9,8,5,6]
squares = [x**2 for  x in num]
print(squares)

#same program by using comprehence by conditions

n=[3,6,9,5,8]
even_square = [x**2 for x in n if x%2==0]
print(even_square)

