
#dictionaries

d={'cat' : 'animal','dove':'bird'}#key and value storing in dictionaries
print(d['cat'])
d['mouse']='animal'
print(d['mouse'])
del d["mouse"]
print(d.get('mouse','n/a'))



d={'cat':4,'human':2,'bird':2}
for i in d:
    legs=d[i]
    print('A %s has %d legs'%(i,legs))


nums = [0, 1, 2, 3, 4]
even_num_to_square = {x: x ** 2 for x in nums if x % 2 == 0}
print (even_num_to_square)  # Prints "{0: 0, 2: 4, 4: 16}"
