x= [[1,2,3],[5,6,3],[3,6,9]]
y= [[9,6,3],[8,9,6],[9,5,2]]
result=[[0,0,0],[0,0,0],[0,0,0]]
for i in range(len(x)):
    for j in range(len(y[0])):
        for k in range(len(y)):
            result[i][j]=x[i][k]*y[k][j]
for r in result:
    print (r)
