class Gt(object):
    def __init__(self,name):
        self.name=name
    def hello(self,loud=False):
        if loud:
            print('HELLO, %s!' %self.name.upper())
        else:
            print('Hello, %s' % self.name)
g=Gt('thebz')
g.hello()
g.hello(loud=True)