hello='hello'
world='world'
print(hello,world)
print('hello'+ ' '+'world')#concatenation
as12 = '%s %s %d' %(hello, world, 1123)# for printing string with integers
print(as12)
